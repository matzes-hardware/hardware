/********************* (C) COPYRIGHT 2010 e-Design Co.,Ltd. ********************
 File Name  : main.c  
 Version    : DS203_APP_PLUS Ver 1.0x                              Author : xie 
 reference  : Version DS203_APP Ver 2.4x                           Author : bure 
*******************************************************************************/
#include <stdlib.h>
#include <string.h>
#include "Interrupt.h"
#include "Function.h"
#include "Calibrat.h"
#include "Process.h"
#include "Ident.h"
#include "Draw.h"
#include "BIOS.h"
#include "Menu.h"
#include "File.h"
#include "USART.h"
//#define DEBUG
#ifdef DEBUG
  void Open_Usart1(void);
#endif
/*******************************************************************************
�汾�޸�˵��
APP V2.30: �Ӹð汾���ټ���PCB_V2.6���°汾������
           �Ӹð汾���ټ���SYS_V1.31���°汾
           ���߶�ʱ�޸�Ϊ600��(Main.c)
           �޸ļ��������µ�SYS�⺯��(BIOS.s)
           �޸��˿�����Ϣ��ʾ����(Main.c)
APP V2.31: �����˿���ʶ��FPGA���������������б�(Main.c)
           ������LicenceȨ�޹������ܵ�Demo������(Ident.c,Main.c)
           �޸���ģ��ͨ��У�����ܵĽ�����˳���ز���(calibrat.c)
           ������144MHz�������ģʽ�µ���ع���(Process.c)
APP V2.32  �Ӹð汾��ɲ���ʹ��IAR 4.42��5.0�汾
           Դ����û�Ķ����������ļ��С�IAR_V5_Prpject
APP V2.33  �޸���ɨ��ʱ��<1uSʱ����ʾˢ�µ�BUG(Process.c)
           �޸�����У׼״̬�£�������ʾ��Ϣ��BUG(Calibrat.c)
APP V2.34  ��Ϊ��ͨ������У׼(Calibrat.c & Main.c)
           �޸���У׼��ѡ��Ĳ�����ʽ(Calibrat.c)
APP V2.35  �޸���У׼�����е�BUG(Calibrat.c)
           �޸���ɨ��ʱ��<5uSʱ����ͣ���˵�BUG(Process.c)
           �Ż�����ʾ���ݴ�������(Process.c)
           ������ģ��ͨ���Զ����ƽ�⹦��(Main.c,Process.c,Calibrat.c)
APP V2.36  ����У׼������Ϊ�Զ�ģʽ(Calibrat.c,Process.c,Function.C)
           �޸��˿������ع��������ķ�ʽ(Main.c)
APP V2.37  ��һ�����ƺ��Ż�����ʾ���ݴ�������(Process.c)
           �޸���32λ�з��ż��޷�������ת���������������BUG(Function.c)
           ������ʱ��Ƶ������ռ�ձȲ�������(Process.c, Menu.c)
APP V2.40  ������дU�̴����ļ�������(Main.c, Flies.c, dosfs.c)
           �޸Ĵ���ʱ��ʾ�ļ����BUG(Menu.c) 
APP V2.41  �������ļ���ʽΪ.BUF�Ķ�/д���������������ļ�(Main.c,Flies.c,Menu.c)
           �������ļ���ʽΪ.CSV�ĵ������������������ļ�(Main.c,Flies.c,Menu.c)
APP V2.42  Ϊ��ʡ�ռ佫�ļ�ϵͳת�Ƶ�SYS_V1.40ģ����(ASM.s, Flies.c, dosfs.c)
           ��Ϊ��"SerialNo.WPT"���ļ���ʽ���湤��������(Flies.c)
           ע��APP V2.42���ϰ汾������SYS V1.40���ϰ汾һ�����ʹ��
APP V2.43  �޸���ģ��ͨ����λ����ʱ��BUG(Main.c)
APP V2.44  �޸��˶�дBUF�ļ�ʱ�ָ���ʾ�˵��и�����Ӧ��ʱ��BUG(Files.c)
//-----------------------------------------------------------------------------
APP(PLUS) Ver1.00  ���漰�����ı䣬��APP V2.51,��SYS V1.50Ϊ�����޸Ķ���
					 ��ϵͳ����SYS V1.51,APP V2.52��V26FPGA�汾һ�����ʹ��
APP(PLUS) V1.01	�޸�����ʾֵFRQ,TH,TL ��BUG(Menu.c,	Function.c)		
APP(PLUS) V1.02	�ı� Yλ��ʱ V1��V2ͬʱ�仯������ʾ���������(Main.c Draw.c)
APP(PLUS) V1.03	�ı� Yλ��ʱ V1��V2���䣬����ʾ���������(Main.c )
APP(PLUS) V1.04	�޸��˵�Ƶ�ʴ�1Mʱ����������BUG(Function.c )
APP(PLUS) V1.05	�޸��˵���ʱ���͵�ѹʱ����ѹʱ ��T����V û�и��µ�BUG(Main.c,Menu.c )
APP(PLUS) V1.06	�޸���FRQ ��ʾֵ��BUG.(Main.c,Menu.c,Function.c )
                �޸���SCAN ����ʱ��BUG.(Process.c )
*******************************************************************************/
//#define APP_VERSION       "     DS203 Mini DSO APP Test Ver 3.13  "	
//#define APP_VERSION       "DS203 Mini DSO APP (PLUS A3) Ver 1.02  "
#define APP_VERSION       	"DS203 Mini DSO APP (PLUS A1) Ver 1.06  "		

uc8 PROJECT_STR[20] = "Demo PROG. Ver 3.00";
int TG;
/*******************************************************************************
  main : Main routine.
*******************************************************************************/
int main(void)
{ 
  u32 i;
  u8 k,limit;
//  u32 Licence;
  u16 Count_FPS=0, Second=0;            //,Offset, Result
static u8 old_Twink=0;              //num=1,Tg2=0,,Tg3=0
static s32 Vv,B2;

	NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0C000);     // For Application #1
//NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x14000);     // For Application #2

//	NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x1C000);   // For Application #3
//NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x24000);     // For Application #4
//Note: �� IAR_V4.x ����ʱ����� App#n ��Ҫͬʱ�޸� lnkarm.xcl �ļ��еĶ�Ӧ�� 
//      �� IAR_V5.x ����ʱ����� App#n ��Ҫͬʱ�޸� xxxxxx.icf �ļ��еĶ�Ӧ�� 
  
  __USB_Init();
  
  if(__Get(FPGA_OK)== 0){
    __Display_Str(6*8, 30, YEL, PRN,(u8*)"      FPGA configuration error       ");
    while (1){};
  }
  __Display_Str(48, 50, WHT, PRN,  (u8*)APP_VERSION);
  Y_Attr = (Y_attr*)__Get(VERTICAL);     
  X_Attr = (X_attr*)__Get(HORIZONTAL);
  G_Attr = (G_attr*)__Get(GLOBAL);
  T_Attr = (T_attr*)__Get(TRIGGER);
  Load_Attr();// ��ֵY_Attr��
  i=Load_Param(); // ��ȡԤ�迪������ 
  if(i == 0)  // ��ȡԤ�迪������
    __Display_Str(6*8, 30, GRN, PRN, (u8*)"     Reload parameter form disk       ");
  else       
    __Display_Str(6*8, 30, YEL, PRN,(u8*) "     Parameter record not found       ");  
//--------------------------- LICENCE_CTRL_DEMO --------------------------------
/*  
  Offset = Seek_Proj(PROJECT_ID);
  if(Offset >= 2048){                          // Project ID not found
    Offset = Seek_Blank();
    if(Offset == 2048){  
      __Display_Str(6*8, 50, GRN, PRN,  (u8*)"         Licence record full         ");
      while (1){};
    } else {
      Result  = Add_Proj(PROJECT_ID, Offset);  // Set project ID
      Result &= Add_Cnt(DEMOCNT, Offset);      // Set max demo run counter      
      Result &= Add_Str((u32)PROJECT_STR, Offset); 
      if(Result != 1){                                
        __Display_Str(6*8,50,GRN, PRN,   (u8*)"       Project ID writen error       ");
        Delayms(500);
      }
    }
  }
  Licence = Get_Lic(Offset);                   // Get project licence record
  if(__Ident(DEVELOPER_ID, PROJECT_ID, Licence)!= 1){
    __Display_Str(6*8, 50, GRN, PRN,   "Please input project licence:00000000");
    Licence = Input_Lic((6+29)*8, 50);         // Input Licence
    if(__Ident(DEVELOPER_ID, PROJECT_ID, Licence)!=1)  Result = 0;
    else{                                      // Licence correct
      Result  = Add_Lic(Licence, Offset);            
      if(Result == 1)                                
        __Display_Str(6*8,50,GRN, PRN, (u8*)"          Licence writen ok          ");
      else  
        __Display_Str(6*8,50,GRN, PRN, (u8*)"         Licence writen error        ");
      Delayms(500);
    }
    if(Result != 1){
      __Display_Str(6*8, 30, GRN, PRN, (u8*)"      Push any key to next step      ");
      while(Key_Buffer == 0){};
    }
  }*/
//--------------------------------------------------------------------------------                               
#ifdef DEBUG
  Open_Usart1();
  USART1Write("usart1 test ",12);
#endif 
  Beep_mS = 500;
  Balance();
  App_init();
  memset(&filenum,1,11);
  Key_Buffer=0;
  __Clear_Screen(BLACK);
  __LCD_DMA_Ready();
  PD_Cnt=Standby*Unit;
  display_flag=1;
	Update=1;
  Display_Trigg();
	VY=(Vt-Title[Trigg[1].Track][2].Value)*_Meas_V_Scale;

//--------------------------------- ��ѭ�� ------------------------------------- 
  while (1){
    if((Standby!=0) &&(PD_Cnt == 0)){
       __Set(BACKLIGHT, 0);     // �رձ���
      __Set(STANDBY, EN);      // ����ʡ��״̬ 
      
    } else {
			if(display_flag) Synchro();
      __LCD_DMA_Ready();                              // ͬ����ʾ�����켣��������
      Count_FPS++;
      if(Second != Sec_Cnt){
        Second = Sec_Cnt;
        Result_FPS = Count_FPS;
        Count_FPS = 0;
        Update_Battery();
        if((Notice_Flag & Meter_Flag)==Meter_Flag)
        {for(i=0; i<8; ++i)Display_Value(i);} // ÿ��ˢ�²���ֵ        
      }
      if(Curr_Status==S_Meter)Display_Meter(); 
      if(Curr_Status==S_Trigg)Update_Trigg();//
      if((Curr_Status==S_Title) && (old_Twink!=Twink))
      {		
        _Curr[_Det].Flag |= UPDAT;
        Show_Title();
        old_Twink=Twink;
      }
      __LCD_DMA_Ready(); 
	if(Update){                             // ������������Ҫˢ�µ���Ŀ
        Update_Range();
        Update_Base();
        Update_Output();
        Update_Trig();
        Update_Mark();
        __Set(BACKLIGHT, 10*(Trigg[BK_LIGHT].Value1+1));//Title[BK_LIGHT][CLASS].Value+1)
        if(_X_View.Flag & UPDAT)Update_View_Area();        
        Update = 0;                           // Update finish
      }
    }
//------------------------------ ��������ѭ�� ---------------------------------- 
   if(Key_Buffer){ 
      if((Standby!=0) &&(PD_Cnt == 0))
      { App_init();          // �˳�ʡ��״̬
        Display_Trigg();
        Show_Title();
      }
      PD_Cnt = Standby*Unit;                       // 600��
      switch(Key_Buffer){
        case KEY_P:
          _State.Value = 1-_State.Value;                 // "RUN/HOLD" ״̬����
          _State.Flag |= UPDAT;                          // ����Ӧ�ĸ��±�־
//------Test Use-----------------------------------				
//			if(_State.Value==1)Save_Bmp(num++);
//--------------------------------------------------
				if(Curr_Status!=S_Title)Show_Title();
        if(_Mode == SIGN){
          for(i=0; i<4*X_SIZE; ++i)  TrackBuff[i] = 0; // ����ɵ���ʾ����
        __Set(FIFO_CLR, W_PTR); }                     // FIFOдָ�븴λ
          break;
        case  KEY2:
          if(Curr_Status==S_Menu)ExitMeter(S_Menu);
					else{
 						if(Curr_Status==S_Trigg)ExitMeter(S_Trigg);
            if(Curr_Status<S_Menu) 
            {
              if((Notice_Flag & Meter_Flag)==Meter_Flag)ExitMeter(1);
              Curr_Status=S_Menu;
              
							filenum[7]=Trigg[BK_LIGHT].Value1;
							filenum[8]=Trigg[VOLUME].Value1;
							filenum[9]=Standby;
              filenum[10]=0;
							CurrCom=0;
              ShowMenu();
            }
           } 
          break;
        case  KEY3:
          if(Curr_Status<S_Menu)
          {
            Delay_Cnt = 1000;
            while (Delay_Cnt > 0){
              if((__Get(KEY_STATUS)& KEY3_STATUS)!=0) break; 
            }
            if(Delay_Cnt == 0)SetMeter(1);      
            else{  
              if(Notice_Flag & Meter_Flag)
                Notice_Flag &=(~Meter_Flag);
              else
                Notice_Flag|=Meter_Flag;
              show_notice(); }
           } 
          break;  
        case  KEY4:
          if(Curr_Status==S_Trigg)ExitMeter(2);
          else
          {
						if(Curr_Status<S_Menu)
							SetMeter(2);
					}
           break; 
        case  K_INDEX_INC:
          if(Curr_Status==S_Title)
          {
            if(_Curr[_Det].Value <_Curr[_Det].Limit )_Curr[_Det].Value++;
            else if(_Curr[_Det].MARK & CIRC)_Curr[_Det].Value  = 0;
            switch (Current){
               case  OUTPUT:
                 if((Title[OUTPUT][SOURCE].Value != DIGI)&&(Title[OUTPUT][FRQN].Value > 10)){
                  	Title[OUTPUT][FRQN].Value = 10;            // ģ���ź�Ƶ������Ϊ20KHz 
                    Title[OUTPUT][FRQN].Flag |= UPDAT;
                 }
              	break;
              	case 0:
              	case 1:
                	if((_Det==1)&&(Trigg[SOURCE].Track==Current))
									{
										B2=Y_Attr[_Curr[_Det].Value].SCALE;
										Trigg[1].Value1=_Curr[2].Value+VY/B2;
										if(Trigg[1].Value1>198)Trigg[1].Value1=198;	
										Vt=Trigg[1].Value1;                           //Vt=��������ֵ
										V_Trigg[Trigg[SOURCE].Track].Value=Vt;
										display_item(THR,VY,SOURCE);
										Trigg[2].Flag |= UPDAT;
									}
                  //if(_Det==1)//&&(Trigg[2].Track==Current))
                    display_Vernie_item();
									break;
                  case T_BASE:
                    if(_Det==1)//&&(Trigg[SOURCE].Track==Current))
                      display_Tbase_item();  
                    break;
          	}
						_Curr[_Det].Flag |= UPDAT;
					}
       //------------------
        if(Curr_Status==S_Meter)
        { 
          if(CurrCom==METER_8)
          {
            if(Meter[CurrCom].Item == Ext)
              Meter[CurrCom].Item =Sav;
            else
              Meter[CurrCom].Item = Ext;
          }
          else
          {
            if(Meter[CurrCom].Item < TL)//MIN)  
              Meter[CurrCom].Item += 1;          // �ı������Ŀ
            else                     
              Meter[CurrCom].Item  = VBT;
            if(Meter[CurrCom].Item == VBT) 
              Meter[CurrCom].Track = 4;
            if(Meter[CurrCom].Item == VPP) 
              Meter[CurrCom].Track = 0;
          }
          Meter[CurrCom].Flag |= UPDAT;
         }
         //---- INDEX INC---------------------
         if(Curr_Status==S_Trigg)
        {
          switch (CurrCom){
            case  0:    //������ʽѡ��
            case  TRIGG_EXT:    //exit
              if(Trigg[CurrCom].Value2 < Trigg[CurrCom].Limit2)//MIN)  
                  Trigg[CurrCom].Value2 ++;          
              else
                  Trigg[CurrCom].Value2  = 0;
            break;
            case  1://THRIGG
              if(Trigg[CurrCom].Value1 < Trigg[CurrCom].Limit2)//MIN)  
                Trigg[CurrCom].Value1 ++; 
                 VtColor = Palette[Trigg[CurrCom].Track];
                Vt=Trigg[CurrCom].Value1;
                V_Trigg[Trigg[CurrCom].Track].Value=Vt;
                VY=(Vt-Title[Trigg[1].Track][2].Value)*_Meas_V_Scale;
		            display_item(THR,VY,SOURCE);
              break;
            case  2:
            case  3:
                if(Trigg[CurrCom].Value1 < Trigg[CurrCom].Limit2)  
                    Trigg[CurrCom].Value1 ++;
                Vv1=Trigg[2].Value1;
                Vv2=Trigg[3].Value1; //
								Vv=Trigg[CurrCom].Value1*(Y_Attr[Title[Trigg[CurrCom].Track][1].Value].SCALE);
                display_item((u8*)&ITEM_V[CurrCom-2][0],Vv,CurrCom);  
            break;
            case  4:
            case  5:  
              if(Trigg[CurrCom].Value1 < Trigg[CurrCom].Limit2)  
                  Trigg[CurrCom].Value1 ++;
              T1Posi=Trigg[4].Value1;
              T2Posi=Trigg[5].Value1;
             break;
            case  6:///YPOS
//-----????????---------------------------------------------------------------//
              if(Title[Trigg[CurrCom].Track][2].Value<Title[Trigg[CurrCom].Track][2].Limit)
              {
                if(Trigg[CurrCom].Track==Trigg[1].Track)
                { 
                  if(Trigg[1].Value1<Title[Trigg[1].Track][2].Limit)
                  { 
                    Trigg[1].Value1++;
                    Title[Trigg[CurrCom].Track][2].Value++;
                    Vt=Trigg[1].Value1;
                    V_Trigg[Trigg[1].Track].Value=Vt;
                  }
                }
                else
                  Title[Trigg[CurrCom].Track][2].Value++;
               /* if(!V1_HIDE)
                {
                  if(Trigg[2].Value1 < Trigg[2].Limit2)Trigg[2].Value1++;
                  else Tg2++;

                  if(Tg3>0)Tg3--;
                  else { Trigg[3].Value1++;};
                  Vv1=Trigg[2].Value1;
                  Vv2=Trigg[3].Value1; 
                }
                display_flag|=UPDAT; */
              }
            break;
            case  7:		//X0-POSI  Title[T_BASE][2].Limit)
							 if(Title[T_BASE][2].Value<((BufModulus[Trigg[TRIGG_BUF].Value2]/30)-12))  
                  Title[T_BASE][2].Value++;
               _X_View.Flag |= UPDAT; 
              // Title[RUNNING][STATE].Value = RUN;         // STATE = RUNNING 
              // Title[RUNNING][STATE].Flag |= UPDAT;       // ˢ�� RUNNING STATE
            break;
            case 8:		//T0
            	if(Trigg[CurrCom].Value1 < Trigg[CurrCom].Limit2)  
                    Trigg[CurrCom].Value1 ++;
							//if(BufModulus[Trigg[TRIGG_BUF].Value2]==360)Trigg[CurrCom].Value1=0;
              if( Trigg[T0].Value1==0)Title[T_BASE][2].Value=0;
  						if( Trigg[T0].Value1==1)Title[T_BASE][2].Value=(BufModulus[Trigg[TRIGG_BUF].Value2]/60)-6;
  						if( Trigg[T0].Value1==2)Title[T_BASE][2].Value=(BufModulus[Trigg[TRIGG_BUF].Value2]-T0_POSI-Xv[Trigg[TRIGG_BUF].Value2])/30-10;	     
							_X_View.Flag |= UPDAT; 
             // Title[RUNNING][STATE].Value = RUN;         // STATE = RUNNING 
             // Title[RUNNING][STATE].Flag |= UPDAT;       // ˢ�� RUNNING STATE                     
            	break;
					case  TRIGG_BUF:  //9
              if(Trigg[CurrCom].Value2 < Trigg[CurrCom].Limit2)  
                  Trigg[CurrCom].Value2 ++;
							Title[T_BASE][2].Value=0;
							Trigg[T0].Value1=0;
							_X_View.Flag |= UPDAT; 
              break;  
           }
           Trigg[CurrCom].Flag |= UPDAT;
          }   

         if((Curr_Status==S_Menu)&&(CurrCom>0))
         {
            if(CurrCom<7)
            {
              if (filenum[CurrCom]<99)filenum[CurrCom]++;
              else filenum[CurrCom]=1;
            }
	     else
	     {
		if(CurrCom<10)
		{
			if (filenum[CurrCom]<Trigg[CurrCom+8].Limit2)
				filenum[CurrCom]++;
			else
			{
              	       if (filenum[CurrCom]<1)
				     filenum[CurrCom]++;
			}		   
		}	
	     }
	     if((CurrCom==7) ||(CurrCom==8)|| (CurrCom==9))process_menu();
            ShowMenu();  
         }
          
          
        break; 
//----------------------------------------------------------          
        case  K_INDEX_DEC:          //----"Index-" Key -----
          if(Curr_Status==S_Title)
          {_Curr[_Det].Flag |= UPDAT; 
            if(_Curr[_Det].Value > 0) _Curr[_Det].Value--;
						else
            	if(_Curr[_Det].MARK & CIRC) _Curr[_Det].Value =0;//_Curr[_Det].Limit  
            switch (Current){
              case  OUTPUT:
                if((Title[OUTPUT][SOURCE].Value != DIGI)&&(Title[OUTPUT][FRQN].Value > 10)){ 
                  Title[OUTPUT][FRQN].Value = 10;            // ģ���ź�Ƶ������Ϊ20KHz 
                  Title[OUTPUT][FRQN].Flag |= UPDAT;
                }
              break;
              case 0:
              case 1:
                if((_Det==1)&&(Trigg[SOURCE].Track==Current))
 								{
									B2=Y_Attr[_Curr[_Det].Value].SCALE;
									Trigg[1].Value1=_Curr[2].Value+VY/B2;
									if(Trigg[1].Value1<5)Trigg[1].Value1=5;
									if(Trigg[1].Value1>195)Trigg[1].Value1=195;
									Vt=Trigg[1].Value1;
									V_Trigg[Trigg[SOURCE].Track].Value=Vt;
									display_item(THR,VY,SOURCE);
									Trigg[2].Flag |= UPDAT;
                  Trigg[2].Flag |= UPDAT;
								}
                display_Vernie_item();
               break; 
             case T_BASE:
                if(_Det==1)display_Tbase_item(); 
               break;
          }
					_Curr[_Det].Flag |= UPDAT;
         }//---------------S_Title end;
        if(Curr_Status==S_Meter)
        {
          if(Meter[CurrCom].Item  > VBT) 
            Meter[CurrCom].Item -= 1;          // �ı������Ŀ 
          else                     
            Meter[CurrCom].Item  = TL;//MIN;
          if(Meter[CurrCom].Item == FPS) 
            Meter[CurrCom].Track = 4;
          if(Meter[CurrCom].Item == TL)//MIN) 
            Meter[CurrCom].Track = 0;
          Meter[CurrCom].Flag |= UPDAT;  
        }//--------index-dec---------------
        if(Curr_Status==S_Trigg)
        { 
          switch (CurrCom){
            case  0:    //������ʽѡ��
            case  TRIGG_EXT:    //Sselect SAVE OR EXIT 
              if(Trigg[CurrCom].Value2 >0) //MIN)  
                Trigg[CurrCom].Value2 --;          
              else
                Trigg[CurrCom].Value2  = Trigg[CurrCom].Limit1;
            break;
            case  1://THRIGG
              	if(Trigg[CurrCom].Value1>Trigg[CurrCom].Limit1)      //(MIN)
                 	Trigg[CurrCom].Value1 --;
                 	
              	Vt=Trigg[CurrCom].Value1;
              	V_Trigg[Trigg[CurrCom].Track].Value=Vt;
              	VtColor = Palette[Trigg[CurrCom].Track];
              	VY=(Vt-Title[Trigg[1].Track][2].Value)*_Meas_V_Scale;
								display_item(THR,VY,SOURCE);
	          break;
            case  2://V1,V2
            case  3:
              if(Trigg[CurrCom].Value1>Trigg[CurrCom].Limit1)      //(MIN)
                 Trigg[CurrCom].Value1 --;
              Vv1=Trigg[2].Value1;
              Vv2=Trigg[3].Value1; 
              Vv=Trigg[CurrCom].Value1*(Y_Attr[Title[Trigg[CurrCom].Track][1].Value].SCALE);
							display_item((u8*)&ITEM_V[CurrCom-2][0],Vv,CurrCom);  
              display_Vernie_item();
            break;
            case  4://T1,T2
            case  5:
              if(Trigg[CurrCom].Value1>Trigg[CurrCom].Limit1)      //(MIN)
                 Trigg[CurrCom].Value1 --;
              T1Posi=Trigg[4].Value1;
              T2Posi=Trigg[5].Value1;
             break;
            case  6:  //ypos
              if(Title[Trigg[CurrCom].Track][2].Value>0)
              {  
                if(Trigg[CurrCom].Track==Trigg[1].Track)
                { 
                  if(Trigg[1].Value1>0)
                  { 
                    Trigg[1].Value1--;
                    Title[Trigg[CurrCom].Track][2].Value--;
                    Vt=Trigg[1].Value1;
                    V_Trigg[Trigg[1].Track].Value=Vt;
                  }
                }
                else
                  Title[Trigg[CurrCom].Track][2].Value--;
              }
/*              if(Title[Trigg[CurrCom].Track][2].Value>0)
              {  
                if(Trigg[CurrCom].Track==Trigg[1].Track)
                { 
                  if(Trigg[1].Value1>0)
                  { 
                    Trigg[1].Value1--;
                    Title[Trigg[CurrCom].Track][2].Value--;
                    Vt=Trigg[1].Value1;
                    V_Trigg[Trigg[1].Track].Value=Vt;
                  }
                }
                else
                  Title[Trigg[CurrCom].Track][2].Value--;
                if(Trigg[3].Value1 > Trigg[3].Limit1) 
                      Trigg[3].Value1--;
                else  Tg3++;
                if(Tg2>0) Tg2--;
                else      Trigg[2].Value1--;
                Vv1=Trigg[2].Value1;
                Vv2=Trigg[3].Value1; 
                display_flag|=UPDAT; 
              }*/
            break;
            case  7:  //xpos
              if(Title[T_BASE][2].Value>0)  
                  Title[T_BASE][2].Value--;
              _X_View.Flag |= UPDAT;    // X_POSI����
           //   Title[RUNNING][STATE].Value = RUN;         // STATE = RUNNING 
           //   Title[RUNNING][STATE].Flag |= UPDAT;       // ˢ�� RUNNING STATE
             break;
            case 8://T0
            	if(Trigg[CurrCom].Value1 >0) //MIN)  
                Trigg[CurrCom].Value1 --;
              if( Trigg[T0].Value1==0)Title[T_BASE][2].Value=0;
							if( Trigg[T0].Value1==1)Title[T_BASE][2].Value=(BufModulus[Trigg[TRIGG_BUF].Value2]/60)-6;
  						if( Trigg[T0].Value1==2)Title[T_BASE][2].Value=((BufModulus[Trigg[TRIGG_BUF].Value2]-T0_POSI-Xv[Trigg[TRIGG_BUF].Value2])/30)-10;
	     
							_X_View.Flag |= UPDAT; 
           //    Title[RUNNING][STATE].Value = RUN;         // STATE = RUNNING 
           //    Title[RUNNING][STATE].Flag |= UPDAT;       // ˢ�� RUNNING STATE        
            	break;
						case  TRIGG_BUF://9
              if(Trigg[CurrCom].Value2>Trigg[CurrCom].Limit1)      //(MIN)
                 Trigg[CurrCom].Value2 --;
							Title[T_BASE][2].Value=0;
							Trigg[T0].Value1=0;
							_X_View.Flag |= UPDAT; 
             break;
          }
          Trigg[CurrCom].Flag |= UPDAT;
 					Trigg[T0].Flag |= UPDAT;
       }
          
//-------------------------------
       if((Curr_Status==S_Menu)&&(CurrCom>0))
       {
            if(CurrCom<7)
            { if(filenum[CurrCom]>1)filenum[CurrCom]--;
              else filenum[CurrCom]=99; 
            }
            else
						{	if(CurrCom<10)
							{
								if (filenum[CurrCom]>Trigg[CurrCom+8].Limit1)filenum[CurrCom]--;
							}
							else
              	if(filenum[CurrCom]>0)filenum[CurrCom]--;
						}
						if((CurrCom==7) ||(CurrCom==8)|| (CurrCom==9))process_menu();
            ShowMenu();
       }
        break; 
//===========index dec=========================================                   
        case  K_INDEX_S:
          if(Curr_Status==S_Title)
          { _Curr[_Det].Flag |= UPDAT;                          
            for(k=0;k<3;k++)
            {
              if(_Det < 3)    _Det ++;
              else            _Det  = 0;
              if(_Curr[_Det].MARK!=NOT)break;
            }
            _Curr[_Det].Flag |= UPDAT;   // �ı�Detail 
               
          }
          if(Curr_Status==S_Meter)
          {
            if(CurrCom==METER_8)
            {
                if(Meter[CurrCom].Item == Sav)Save_Param();
                ExitMeter(1);
            }
            else
            {// �ı��������
              if(Meter[CurrCom].Track <=  TRACK4) 
                Meter[CurrCom].Track += 1;
              if(Meter[CurrCom].Track > TRACK4) 
                Meter[CurrCom].Track  = TRACK1;
              Meter[CurrCom].Flag |= UPDAT;  
            }
          }
          if(Curr_Status==S_Trigg)//------k-index-s--------------------
          { 
            
            if ((CurrCom>1) && (CurrCom<6))limit=4;
						else limit=TRACK4;
						if((CurrCom<7)&&(CurrCom!=4)&&(CurrCom!=5))
            {
              if(Trigg[CurrCom].Track <limit) //TRACK4
                Trigg[CurrCom].Track ++;
              else
                  Trigg[CurrCom].Track = TRACK1;
            }
            switch  (CurrCom){
              case  0:
                  if(Trigg[CurrCom].Track <2)
                  {   Trigg[1].Track = Trigg[CurrCom].Track;
                      Trigg[1].Flag |= UPDAT;
                      Trigg[1].Value1= V_Trigg[Trigg[1].Track].Value;
                      VtColor = Palette[Trigg[1].Track]; 
                      Vt=Trigg[1].Value1;
                  }
              break;
              case  1:
								if(Trigg[CurrCom].Track>1)
								{
										if(Trigg[CurrCom].Track==4)
												Trigg[CurrCom].Track=0;
										else 
												Trigg[CurrCom].Track=4;
								}
								if(Trigg[CurrCom].Track==4)Vt_HIDE=1;
								else
								{	Vt_HIDE=0;
                	Trigg[CurrCom].Value1= V_Trigg[Trigg[CurrCom].Track].Value;
                	VtColor = Palette[Trigg[CurrCom].Track]; 
                	Vt=Trigg[CurrCom].Value1;
                	Trigg[0].Track=Trigg[CurrCom].Track;
                	Trigg[0].Flag |= UPDAT;
								}
								
              break;
              case  2:
                if(Trigg[CurrCom].Track>1)
								{
										if(Trigg[CurrCom].Track==4)
												Trigg[CurrCom].Track=0;
										else 
												Trigg[CurrCom].Track=4;
								}
								if(Trigg[CurrCom].Track==4)
								{	V1_HIDE = 1;                            // V1�α�����ʾ/������־
									V2_HIDE = 1;                            // V2�α�����ʾ/������־
								}
								else
								{	V1_HIDE = 0;                            // V1�α�����ʾ/������־
									V2_HIDE = 0;                            // V2�α�����ʾ/������־
								}
                Trigg[3].Track=Trigg[CurrCom].Track;
                Trigg[3].Flag |= UPDAT;
              break;
              case  3:
                if(Trigg[CurrCom].Track>1)
								{
										if(Trigg[CurrCom].Track==4)
												Trigg[CurrCom].Track=0;
										else 
												Trigg[CurrCom].Track=4;
								}
								if(Trigg[CurrCom].Track==4)
								{	V1_HIDE = 1;                            // V1�α�����ʾ/������־
									V2_HIDE = 1;                            // V2�α�����ʾ/������־
								}
								else
								{	V1_HIDE = 0;                            // V1�α�����ʾ/������־
									V2_HIDE = 0;                            // V2�α�����ʾ/������־
								}
                Trigg[2].Track=Trigg[CurrCom].Track;
                Trigg[2].Flag |= UPDAT;
              break;
							case 4:
							case 5:
								if(Trigg[CurrCom].Track==5)
								{	 Trigg[CurrCom].Track=4;                           
										T1_HIDE = 1;                            
										T2_HIDE = 1;                          
								}
								else
								{	Trigg[CurrCom].Track=5;                         
									T1_HIDE = 0;                            
									T2_HIDE = 0;                             
								}
								Trigg[4].Track=Trigg[CurrCom].Track;
								Trigg[5].Track=Trigg[CurrCom].Track;
								Trigg[4].Flag |= UPDAT;
								Trigg[5].Flag |= UPDAT;
								break;
							case 8:
								if(Trigg[CurrCom].Track==5)
								{	 Trigg[CurrCom].Track=4;                           
									T0_HIDE = 1;                            
								}
								else
								{	Trigg[CurrCom].Track=5;                         
									T0_HIDE = 0;                            
								}
							break;
              case  9:
                if(Trigg[CurrCom].Value2 == 1)Save_Param();
                ExitMeter(2);
              break;
            }
            Trigg[CurrCom].Flag |= UPDAT;
          }
           if(Curr_Status==S_Menu)process_menu();
          break;    
        
        case  K_ITEM_INC:       //"Item+" Key
          if(Curr_Status==S_Title) //|| (Curr_Status==S_Tirgg))
          {_Curr[_Det].Flag |= UPDAT;
            if(Current < (ITEM2-1))Current ++; // Current = TRACK1;
            if(Current == RUNNING) Current ++;              // Jump over RUNNING
            if(_Det >=3)    _Det =0;
						_Curr[_Det].Flag |= UPDAT; 
           }
          if(Curr_Status==S_Meter)
          {
            Meter[CurrCom].Flag |= UPDAT;  
            if(CurrCom == METER_8) CurrCom  = METER_0;
            else                   CurrCom ++;
            Meter[CurrCom].Flag |= UPDAT;
          }
          if(Curr_Status==S_Trigg)
          {
            Trigg[CurrCom].Flag |= UPDAT;  
            if(CurrCom >= TRIGG_EXT) CurrCom  =0;
            else              CurrCom ++;
            Trigg[CurrCom].Flag |=UPDAT;
            
          }
          if(Curr_Status==S_Menu)
          {
            if(CurrCom==(menu_item-1))CurrCom=0;
            else    CurrCom++;
            ShowMenu();
          }
          break;                      
        case  K_ITEM_DEC:
          if(Curr_Status==S_Title)
          {_Curr[_Det].Flag |= UPDAT;
            if(Current > ITEM1) Current --; 
            if(Current == RUNNING) Current --;               // Jump over Item 4
            if(_Det >=3)  _Det =0;
						_Curr[_Det].Flag |= UPDAT;
           }
          if(Curr_Status==S_Meter)
          {
            if(CurrCom == METER_0) CurrCom = METER_8;
            else                   CurrCom --;
            Meter[CurrCom].Flag |= UPDAT;   
          }
          if(Curr_Status==S_Trigg)
          {
						Trigg[CurrCom].Flag |= UPDAT;  

            if(CurrCom >0)  CurrCom --;
            else CurrCom = TRIGG_EXT;            
            Trigg[CurrCom].Flag |= UPDAT;
  
          }
          if(Curr_Status==S_Menu)
          {
            if(CurrCom==0)CurrCom=(menu_item-1);
            else    CurrCom--;
            ShowMenu();    
          }
          break;  
        case  K_ITEM_S:
          if(Curr_Status==S_Meter)ExitMeter(1); 
         // if(Curr_Status==S_Trigg)ExitMeter(2);
          if(Curr_Status==S_Menu)ExitMeter(3);
           break;  
        default:

          break;
     }  //switch end
     Key_Buffer=0;
      Update = 1;
    }
  };//while end
}

/*********************************  END OF FILE  ******************************/

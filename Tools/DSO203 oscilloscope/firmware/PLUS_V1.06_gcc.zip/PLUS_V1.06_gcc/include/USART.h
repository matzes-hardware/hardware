#ifndef __USART_H
#define __USART_H

//#include "type.h"
void USART2_SendByte(u16 dat);
void USART1_SendByte(u16 dat);


void USART1_Configuration(void);
void USART2_Configuration(void);

void USART1Write(u8* data,u16 len);
void USART2Write(u8* data,u16 len);


void U1_IRQHandler(void);
void U2_IRQHandler(void);

#define DIR485_H  GPIOC->BSRR=1<<1
#define DIR485_L  GPIOC->BRR=1<<1 


#endif

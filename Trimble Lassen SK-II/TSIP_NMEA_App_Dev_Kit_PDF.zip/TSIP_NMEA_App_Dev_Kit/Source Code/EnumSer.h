/*+ EnumSer.h
 *
 ******************************************************************************
 *
 *                        Trimble Navigation Limited
 *                           645 North Mary Avenue
 *                              P.O. Box 3642
 *                         Sunnyvale, CA 94088-3642
 *
 ******************************************************************************
 *
 *    Copyright (c) 1998 - 2001 by PJ Naughter.  
 *                         (Web: www.naughter.com, Email: pjna@naughter.com)
 *    All Rights Reserved
 *
 ******************************************************************************
 *
 * Description:
 *    This file defines the interface for a number of functions to enumerate 
 *    the serial ports installed on a PC.
 *            
 * Revision History:
 *    05-18-2005    Mike Priven
 *                  Adopted to this project.
 *
 * Notes:
 *
-*/

#ifndef ENUM_SER_H
#define ENUM_SER_H
                      
#ifndef __AFXTEMPL_H__
#pragma message("To avoid this message put afxtempl.h in your PCH")                                                                                
#include <afxtempl.h>
#endif


/*---------------------------------------------------------------------------*\
 |                      C L A S S   D E F I N I T I O N
\*---------------------------------------------------------------------------*/
class CEnumSer
{

public: //==== P U B L I C   M E T H O D S ===================================/
        
    void EnumSerialPorts (CUIntArray& arrPorts);


private: //==== P R I V A T E   M E T H O D S ================================/

    BOOL EnumMethod1 (CUIntArray& ports);
    BOOL EnumMethod2 (CUIntArray& ports);
    BOOL EnumMethod3 (CUIntArray& ports);
    BOOL IsNumeric   (LPCTSTR pszString);
    void AddData     (CUIntArray &arrPorts, UINT uiData);
};

#endif

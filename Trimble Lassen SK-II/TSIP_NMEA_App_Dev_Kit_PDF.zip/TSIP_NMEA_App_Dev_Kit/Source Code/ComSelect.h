/*+ ComSelect.h
 *
 ******************************************************************************
 *
 *                        Trimble Navigation Limited
 *                           645 North Mary Avenue
 *                              P.O. Box 3642
 *                         Sunnyvale, CA 94088-3642
 *
 ******************************************************************************
 *
 *    Copyright � 2005 Trimble Navigation Ltd.
 *    All Rights Reserved
 *
 ******************************************************************************
 *
 * Description:
 *    This file defines the CComSelect class.
 *            
 * Revision History:
 *    05-18-2005    Mike Priven
 *                  Written
 *
 * Notes:
 *
-*/

#ifndef COM_SELECT_H
#define COM_SELECT_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


/*---------------------------------------------------------------------------*\
 |             F O R W A R D   C L A S S   D E C L A R A T I O N S
\*---------------------------------------------------------------------------*/
class CTsipWindow;


/*---------------------------------------------------------------------------*\
 |                      C L A S S   D E F I N I T I O N
\*---------------------------------------------------------------------------*/
class CComSelect : public CDialog
{

public: //==== P U B L I C   M E T H O D S ===================================/

    CComSelect (CWnd* pParent = NULL);


public: //==== P U B L I C   M E M B E R   V A R I A B L E S =================/

    //{{AFX_DATA(CComSelect)
    enum { IDD = IDD_COM_CHOOSER };
    CComboBox   m_lstComStop;
    CComboBox   m_lstComData;
    CComboBox   m_lstComPort;
    CComboBox   m_lstComBaud;
    CComboBox   m_lstComParity;
    BOOL        m_bSetRcvr;
    //}}AFX_DATA


protected: //==== P R O T E C T E D   M E T H O D S ==========================/

    //{{AFX_VIRTUAL(CComSelect)
    virtual void DoDataExchange(CDataExchange* pDX);
    //}}AFX_VIRTUAL

    //{{AFX_MSG(CComSelect)
    virtual BOOL OnInitDialog();
    virtual void OnOK();
    afx_msg void OnClose();
    virtual void OnCancel();
    //}}AFX_MSG

    DECLARE_MESSAGE_MAP()


private: //==== P R I V A T E   M E M B E R   V A R I A B L E S ==============/

    CTsipWindow *m_pParent;
};

#endif
